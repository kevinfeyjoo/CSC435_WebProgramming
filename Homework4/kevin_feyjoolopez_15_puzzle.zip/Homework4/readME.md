"The 15-puzzle and its smaller version, the 8-puzzle are classic sliding puzzles, consisting of numbered square tiles which can be slid in a frame using an empty slot. The object is to slide all tiles where they belong using the empty space. The solved state can be marked with numbers or an image. One possible solution of the numbered verion is shown on the image supplied."

my_15_puzzle(under construction):
https://kevinfeyjoo.github.io/CSC435_WebProgramming/Homework4/fifteen.html

src:
https://ruwix.com/twisty-puzzles/sliding-15-puzzle/
